/*
 */
package lab07;

/**
 *
 * @author MattCasiro
 */
public enum Direction {
    NULL,   // Indicates a stationary state
    UP,     // Indicates an upward direction
    DOWN    // Indicates a downward direction
}
