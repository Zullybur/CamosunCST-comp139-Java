/*
 */
package lab07;

/**
 *
 * @author MattCasiro
 */
public enum DoorType {
    OUTER,  // Indicates a door attached to a floor
    INNER   // Indicates a door belonging to an elevator
}
